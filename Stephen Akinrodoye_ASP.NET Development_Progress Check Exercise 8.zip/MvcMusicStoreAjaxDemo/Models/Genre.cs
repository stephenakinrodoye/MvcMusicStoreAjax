﻿namespace MvcMusicStoreAjaxDemo.Models
{
    public class Genre
    {
        public string Name { get; set; } = "";
    }
}
